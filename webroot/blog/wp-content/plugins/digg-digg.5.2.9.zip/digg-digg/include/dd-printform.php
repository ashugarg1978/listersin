<?php 
require_once 'dd-global-variable.php';

include("template/dd-template-global.php");
include("template/dd-template-normal-display.php");
include("template/dd-template-floating-display.php");
include("template/dd-template-feedback.php");
include("template/dd-template-manual-display.php");
?>