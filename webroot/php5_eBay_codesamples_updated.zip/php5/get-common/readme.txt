This contains the code which is common to all the 
Get... samples (GetCategories, GeteBayOfficialTime...)